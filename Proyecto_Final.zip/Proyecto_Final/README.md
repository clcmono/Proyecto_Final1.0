## INFORME
![alt text](LOGO.jpg)
- Carrera: Computación
- Materia: Estructura de Datos
- Integrantes: Valeria Mantilla y Claudia Quevedo
- correos: amantillac3@est.ups.edu.ec / cquevedor@est.ups.edu.ec

## Descripción del problema


## Propuesta de solución:
## Marco Teórico
La programación dinámica es una técnica de optimización en algoritmos que resuelve problemas complejos al descomponerlos en subproblemas más simples, almacenando sus resultados para evitar cálculos redundantes. Esto se logra mediante dos enfoques principales: top-down (con memorización) y bottom-up (tabulación). Al abordar cada subproblema de forma independiente y reutilizar sus soluciones almacenadas, se mejora significativamente la eficiencia de algoritmos recursivos, comúnmente aplicados en problemas de optimización como la secuencia de Fibonacci.


## Descripción de la propuesta de solución, herramientas y/o lenguajes que usaron.

## Criterio por integrante de su propuesta.

## Capturas de la implementación final de la UI.

## Conclusiones:

## Consideraciones:

